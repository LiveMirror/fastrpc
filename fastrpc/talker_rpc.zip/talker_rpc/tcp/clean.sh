cur_dir=`pwd`;
cd ependingpool
make clean
cd $cur_dir

cd http_codec
make clean
cd $cur_dir

cd svr
make clean
cd $cur_dir


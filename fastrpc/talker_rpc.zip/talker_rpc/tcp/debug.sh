cur_dir=`pwd`;
cd ependingpool
make clean
make debug=1
cd $cur_dir

cd http_codec
make clean
make debug=1
cd $cur_dir

cd svr
make clean
make debug=1
cd $cur_dir

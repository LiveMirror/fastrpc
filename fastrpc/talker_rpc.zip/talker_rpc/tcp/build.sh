cur_dir=`pwd`;
cd ependingpool
make clean
make
cd $cur_dir

cd http_codec
make clean
make
cd $cur_dir

cd svr
make clean
make
cd $cur_dir

#ifndef ECHO_APP_H_
#define ECHO_APP_H_

#include "tapp/tapp_cpp.h"
#include "ApolloFrameWork.h"
#include "ApolloTConnTalker.h"
#include "xcore_rpc_common.h"
#include "xcore_smart_ptr.h"
#include "closure.h"
#include "tcp_server.h"

#include <map>
#include <string>

using namespace tapp;
using namespace apollo;
using std::map;
using std::string;

#define RegiMsgHandler(svr,msg,...) \
    svr.RegiObjMsgCallBack(msg::staticTypeName(), __VA_ARGS__); \
    svr.RegiConstruct(msg::staticTypeName(), msg::staticNewOne);

#define RegiObjMsgCallBack(cmd,...) \
    InnerRegiObjMsgCallBack(cmd,(OBJ_EMSG_CALLBACK)NewPermanentClosure(__VA_ARGS__))

class ETConnConnection;
class ETConnRecvedMsg;

// 静态函数指针
typedef int (*EMSG_CALLBACK)(void* environment,
        ITConnTalker* talker,
        shared_ptr<ETConnConnection> conn,
        const shared_ptr<ETConnRecvedMsg> msg);
typedef std::pair<EMSG_CALLBACK, void*> Ex_MSG_PAIR;

// 类成员函数指针(通过闭包实现)
typedef Closure<int,ITConnTalker*,
        shared_ptr<ETConnConnection>,
        const shared_ptr<ETConnRecvedMsg> >* OBJ_EMSG_CALLBACK;
typedef std::pair<OBJ_EMSG_CALLBACK, void*> OBJ_Ex_MSG_PAIR;

// 这几个类在talker里面，为了不动talker代码这里拷贝一份先
class ETConnConnection : public ITConnConnection {
    public:
        ETConnConnection(int32_t iConnIdx, uint64_t ullID, int32_t sessionFlag, uint64_t callback)
            : ITConnConnection(iConnIdx, ullID, sessionFlag, callback) {}

        bool NeedSession() const { return needSession; }
};

class ETConnRecvedMsg : public ITConnRecvedMsg {
    public:
        ETConnRecvedMsg(const char* cmd, const ITdrObject* obj,
                        MSG_TYPE type, uint32_t async, const TFRAMEHEAD& tframehead)
            : cmd_(cmd), obj_(obj), type_(type), async_(async), tframehead_(tframehead) {}
        ~ETConnRecvedMsg() {
            RpcSafeFree(obj_);
        }

    public:
        const char* GetCmd() const {
            return cmd_;
        }

        const ITdrObject* GetObj() const {
            return obj_;
        }

        MSG_TYPE GetType() const {
            return type_;
        }

        uint32_t GetAsync() const {
            return async_;
        }

        const TFRAMEHEAD& GetTFrameHead() const {
            return tframehead_;
        }

    private:
        const char* cmd_;
        const ITdrObject* obj_;
        MSG_TYPE type_;
        uint32_t async_;
        const TFRAMEHEAD& tframehead_;
};

class TalkerServer : public IApp, public ITConnEventHandler {
    public:
        TalkerServer();
        ~TalkerServer();

    public:
        virtual int OnInit(void* cfg,
                           void* runcumu,
                           void* runstatus,
                           LPTLOGCATEGORYINST tlogcat);
        virtual int OnCleanUp();

        virtual int OnUpdate();
        virtual int OnTick();

        /* set tappctx before init if necessary */
        virtual int SetTappCtxPara();

    public:
        virtual int OnConnectionStart(ITConnConnection& connection, TFRAMEHEAD& tconnd_head);
        virtual int OnConnectionStop(ITConnConnection& connection, TFRAMEHEAD& tconnd_head);
        virtual int OnConnectionDrop(ITConnConnection& connection, const char* reason);

    public: // for rpc
        int RegiMsgCallBack(const char* cmd, EMSG_CALLBACK fun, void* env = NULL);
        int InnerRegiObjMsgCallBack(const char* cmd, OBJ_EMSG_CALLBACK fun);
        int RegiConstruct(const char* cmd, CONSTRUCTFUN fun);
        int RegiTcpSvr(std::string host, int port);

    private:
        int InitTalkerSDK(const char* talker_url);
        void FiniTalkerSDK();

    public:
        static void RunHandler(OBJ_Ex_MSG_PAIR cbPair, ITConnTalker* talker,
                shared_ptr<ETConnConnection> conn, const shared_ptr<ETConnRecvedMsg> msg);
        static void RunClientHandler(Ex_MSG_PAIR cbPair, ITConnTalker* talker,
                shared_ptr<ETConnConnection> conn, const shared_ptr<ETConnRecvedMsg> msg);
        static int MainProc(void* env, ITConnTalker* talker,
                             ITConnConnection& conn,
                             const ITConnRecvedMsg& msg);
        static unsigned GetNextFlow() {
            flow = ((flow == 0 || flow == 0xffffffffUL ) ? 1 : flow+1);
            return flow;
        }
    private:
        LPTLOGCATEGORYINST tlogcat_;
        apollo::ITConnTalker* talker_;
        static unsigned flow;
        static map<string, Ex_MSG_PAIR> m_msg_cb;
        static map<string, OBJ_Ex_MSG_PAIR> m_obj_msg_cb;
    public:
        TcpServer* tcp_svr;

};

#endif

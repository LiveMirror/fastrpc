#include "talker_server.h"
#include "closure.h"

unsigned TalkerServer::flow = 0;
map<string, Ex_MSG_PAIR> TalkerServer::m_msg_cb;
map<string, OBJ_Ex_MSG_PAIR> TalkerServer::m_obj_msg_cb;

TalkerServer::TalkerServer() : tlogcat_(NULL), talker_(NULL)
{
    tcp_svr = NULL;
}

TalkerServer::~TalkerServer()
{}

int TalkerServer::InitTalkerSDK(const char* talker_url)
{
    int ret = apollo::CFrameWork::GetFrameWork()->Init(tlogcat_);
    if (ret != 0)
    {
        tlog_error(tlogcat_, 0, 0, "CFrameWork::Init failed, return %d", ret);
        return -1;
    }

    talker_ = apollo::CFrameWork::GetFrameWork()->NewTConnTalker(talker_url, 0);
    if (NULL == talker_)
    {
        tlog_error(tlogcat_, 0, 0, "NewTConnTalker url:%s failed", talker_url);
        return -1;
    }

    talker_->SetEventHandler(this);

    //for (int i = 0; i < echo::MetaLib::TSTR2SN_SIZE; i++)
    //{
    //    apollo::TypeStr2StaticNew* t2sn = echo::MetaLib::typeStr2StaticNew + i;
    //    talker_->RegistMsgConstructor(t2sn->cmd, t2sn->constructor);
    //}

    std::map<string, CONSTRUCTFUN>::iterator cit = RpcCommonMgr::m_confun_dic.begin();
    for (; cit != RpcCommonMgr::m_confun_dic.end(); ++cit) {
        const string& cmd = cit->first;
        talker_->RegistMsgConstructor(cmd.c_str(), cit->second);
    }

    std::map<string, Ex_MSG_PAIR>::iterator it = TalkerServer::m_msg_cb.begin();
    for (; it != TalkerServer::m_msg_cb.end(); ++it) {
        const string& cmd = it->first;
        talker_->RegistMsgCallBack(cmd.c_str(), MainProc);
    }

    std::map<string, OBJ_Ex_MSG_PAIR>::iterator oit = TalkerServer::m_obj_msg_cb.begin();
    for (; oit != TalkerServer::m_obj_msg_cb.end(); ++oit) {
        const string& cmd = oit->first;
        talker_->RegistMsgCallBack(cmd.c_str(), MainProc);
    }

    return 0;
}

void TalkerServer::FiniTalkerSDK()
{
    if (talker_ != NULL)
    {
        apollo::CFrameWork::GetFrameWork()->FreeTConnTalker(talker_);
        talker_ = NULL;
    }
}

void* TcpIOLoop(void* args) {
    TcpServer* tcp_svr = (TcpServer*)args;
    tcp_svr->start();
    return NULL;
}

int TalkerServer::OnInit(void* cfg, void* runcumu, void* runstatus, LPTLOGCATEGORYINST tlogcat)
{
    tlogcat_ = tlogcat;
    fprintf(stdout, "Hello, echo svr\n");
    tlog_info(tlogcat_, 0, 0, "Hello, echo svr");

    SetCoroutineUsedByCurThread();
    int ret = InitTalkerSDK("tconnd://1689/1.1.1.1/1.1.2.1/");
    if (ret != 0)
    {
        tlog_error(tlogcat_, 0, 0, "InitTalkerSDK failed");
        return -1;
    }

    if (tcp_svr) {
        pthread_t tcp_svr_tid = 0;
        pthread_create(&tcp_svr_tid, NULL, TcpIOLoop, tcp_svr);
    }

    return 0;
}

int TalkerServer::OnCleanUp()
{
    FiniTalkerSDK();

    fprintf(stdout, "Bye, echo svr\n");
    tlog_info(tlogcat_, 0, 0, "Bye, echo svr");

    return 0;
}

int TalkerServer::RegiMsgCallBack(const char* cmd, EMSG_CALLBACK fun, void* env) {
    if (NULL == cmd || NULL == fun) {
        return -1;
    }
    const std::map<string, Ex_MSG_PAIR>::iterator iter = m_msg_cb.find(string(cmd));
    if (iter != m_msg_cb.end()) {
        abort();
        return -2;
    }
    m_msg_cb.insert(pair<string, Ex_MSG_PAIR> (string(cmd), Ex_MSG_PAIR(fun, env)));
    return 0;
}

int TalkerServer::InnerRegiObjMsgCallBack(const char* cmd, OBJ_EMSG_CALLBACK fun) {
    if (NULL == cmd || NULL == fun) {
        return -1;
    }
    const std::map<string, OBJ_Ex_MSG_PAIR>::iterator iter = m_obj_msg_cb.find(string(cmd));
    if (iter != m_obj_msg_cb.end()) {
        abort();
        return -2;
    }
    m_obj_msg_cb.insert(pair<string, OBJ_Ex_MSG_PAIR> (string(cmd), OBJ_Ex_MSG_PAIR(fun, NULL)));
    return 0;
}

int TalkerServer::RegiConstruct(const char* cmd, CONSTRUCTFUN fun) {
    if (NULL == cmd || NULL == fun) {
        return -1;
    }
    RpcCommonMgr::m_confun_dic[string(cmd)] = fun;
    return 0;
}

int TalkerServer::RegiTcpSvr(std::string host, int port) {
    tcp_svr = new(nothrow) TcpServer(host, port);
    return (NULL != tcp_svr);
}

void TalkerServer::RunHandler(OBJ_Ex_MSG_PAIR cbPair, ITConnTalker* talker,
        shared_ptr<ETConnConnection> conn, const shared_ptr<ETConnRecvedMsg> msg) {
    cbPair.first->Run(talker,conn,msg);
}

void TalkerServer::RunClientHandler(Ex_MSG_PAIR cbPair, ITConnTalker* talker,
        shared_ptr<ETConnConnection> conn, const shared_ptr<ETConnRecvedMsg> msg) {
    cbPair.first(cbPair.second, talker, conn, msg);
}

typedef bool (*CroRunWithCloure)(Closure<void>*);

int TalkerServer::MainProc(void* env, ITConnTalker* talker,
                           ITConnConnection& conn,
                           const ITConnRecvedMsg& msg)
{
    const ITdrObject* obj = msg.GetObj();
    const std::map<string, OBJ_Ex_MSG_PAIR>::iterator oiter = m_obj_msg_cb.find(string(obj->typeName()));
    if (oiter != m_obj_msg_cb.end()) {
        ITdrObject* obj_c = obj->clone();
        ETConnConnection* p_conn = new ETConnConnection(conn.GetConnIdx(), conn.GetSessionID(),
                conn.GetSessionFlag(), conn.GetBackAddr());
        ETConnRecvedMsg* p_msg = new ETConnRecvedMsg(obj_c->typeName(), obj_c,
                msg.GetType(), msg.GetAsync(), msg.GetTFrameHead());
        shared_ptr<ETConnConnection> sp_conn(p_conn);
        shared_ptr<ETConnRecvedMsg> sp_msg(p_msg);
        OBJ_Ex_MSG_PAIR cbPair = oiter->second;
        Closure<void>* proc_clo = NewClosure(RunHandler, cbPair, talker, sp_conn, sp_msg);
        Closure<void>* cro_closure = (Closure<void>*)NewClosure((CroRunWithCloure)ProcessWithNewCro, proc_clo);
        RpcMgr::PutOutSideQueue(cro_closure);
        return 0;
    }

    const std::map<string, Ex_MSG_PAIR>::iterator iter = m_msg_cb.find(string(obj->typeName()));
    if (iter != m_msg_cb.end()) {
        // 为了不动talker代码，复制一份
        // 协程里yield的话原来的栈变量会销毁
        ITdrObject* obj_c = obj->clone();
        ETConnConnection* p_conn = new ETConnConnection(conn.GetConnIdx(), conn.GetSessionID(),
                conn.GetSessionFlag(), conn.GetBackAddr());
        ETConnRecvedMsg* p_msg = new ETConnRecvedMsg(obj_c->typeName(), obj_c,
                msg.GetType(), msg.GetAsync(), msg.GetTFrameHead());
        shared_ptr<ETConnConnection> sp_conn(p_conn);
        shared_ptr<ETConnRecvedMsg> sp_msg(p_msg);
        Ex_MSG_PAIR cbPair = iter->second;
        Closure<void>* proc_clo = NewClosure(RunClientHandler, cbPair, talker, sp_conn, sp_msg);
        Closure<void>* cro_closure = (Closure<void>*)NewClosure((CroRunWithCloure)ProcessWithNewCro, proc_clo);
        RpcMgr::PutOutSideQueue(cro_closure);
        return 0;
    }
    return 0;
}

int TalkerServer::OnUpdate()
{

    int up_cb_ret = RpcMgr::Update(0);
    int up_talker_ret = CFrameWork::GetFrameWork()->Update();

    if (0 == up_cb_ret || 0 < up_talker_ret) return 0;
    else return -1;


    //TappCtxObject& tappctx_obj = AppLauncher::tappctx_object();
    //int htbus_ = tappctx_obj.get_bus_handler();
    //int tbusid_ = tappctx_obj.get_bus_id();

    //TBUSADDR src = -1;
    //const char* data = NULL;
    //size_t data_len = 0;
    //int ret = tbus_peek_msg(htbus_, &src, &tbusid_, &data, &data_len, 0);
    //if (TBUS_ERR_IS_ERROR(ret))
    //{
        //if (TBUS_ERROR_CHANNEL_IS_EMPTY != TBUS_ERR_GET_ERROR_CODE(ret))
        //{
            //tlog_error(tlogcat_, 0, 0, "tbus_peek_msg failed, return %d detail %s",
                       //ret, tbus_error_string(ret));
        //}

        //return -1;
    //}

    //tlog_debug(tlogcat_, 0, 0, "recv msg[size:%d, string:%s]", (int)data_len, data);

    //ret = tbus_send(htbus_, &tbusid_, &src, data, data_len, 0);
    //if (TBUS_ERR_IS_ERROR(ret))
    //{
        //tlog_error(tlogcat_, 0, 0, "tbus_send failed, return %d detail %s",
                   //ret, tbus_error_string(ret));
    //}

    //tbus_delete_msg(htbus_, src, tbusid_);

}

int TalkerServer::OnTick()
{
    return 0;
}

int TalkerServer::SetTappCtxPara()
{
    TappCtxObject& tappctx_obj = AppLauncher::tappctx_object();
    tappctx_obj.set_tapp_formated_version(1, 0, 0, 1);

    return 0;
}

// ITConnEventHandler
int TalkerServer::OnConnectionStart(ITConnConnection& connection, TFRAMEHEAD& tconnd_head)
{
    if (TFRAMEHEAD_CMD_START != tconnd_head.chCmd)
    {
        tlog_error(tlogcat_, 0, 0,
                   "TFRAMEHEAD.chCmd[%d] is not TFRAMEHEAD_CMD_START, unexpected",
                   tconnd_head.chCmd);
        return -1;
    }

    /* 无状态服务，session为-1 */
    connection.SetSessionID(-1);
    tlog_info(tlogcat_, 0, 0, "recv tconnd start cmd ConnIdx[%u]",
              connection.GetConnIdx());

    return 1;
}

int TalkerServer::OnConnectionStop(ITConnConnection& connection, TFRAMEHEAD& tconnd_head)
{
    if (TFRAMEHEAD_CMD_STOP != tconnd_head.chCmd)
    {
        tlog_error(tlogcat_, 0, 0,
                   "TFRAMEHEAD.chCmd[%d] is not TFRAMEHEAD_CMD_STOP, unexpected",
                   tconnd_head.chCmd);
        return -1;
    }

    tlog_info(tlogcat_, 0, 0, "recv tconnd stop cmd ConnIdx[%u]",
              connection.GetConnIdx());
    return 0;
}

int TalkerServer::OnConnectionDrop(ITConnConnection& connection, const char* reason)
{
    if (NULL != reason)
    {
        tlog_error(tlogcat_, 0, 0, "Talk drop session, reason[%s]", reason);
    }
    else
    {
        tlog_error(tlogcat_, 0, 0, "Talk drop session, reason[unknown reason]");
    }

    return 0;
}

#include "rpc_common.h"

map<string, CONSTRUCTFUN> RpcCommonMgr::m_confun_dic;

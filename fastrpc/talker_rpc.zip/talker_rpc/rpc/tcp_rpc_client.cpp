// Copyright (c) 2013, feimat.
// All rights reserved.
//

#include "rpc_client.h"
#include "monitor.h"
#include "sstream"
#include "pbext.h"
#include "coroutine.h"

void FinishWait(Monitor* monitor) {
    monitor->Notify();
    return;
}

void PushCallBack(RpcClient &cli, IClosure* done) {
    RpcMgr::PutOutSideQueue(done);
}

void TimeCleaner::on_timer(XTimer* pTimer, uint32 id, void* ptr) {
        RpcCliMethod* rcm = rpcclient_->callback_map.Pop(key_);
        if (NULL == rcm) {
            return;
        }
        if (rcm->controller_) {
            ((RpcController*)rcm->controller_)->is_timeout = true;
            ((RpcController*)rcm->controller_)->SetFailed("time out");
        }
        IClosure* cro_done = rcm->cro_done_;
        if (cro_done) {
            PushCallBack(*rpcclient_, cro_done);
        } else {
            IClosure* done = rcm->done_;
            PushCallBack(*rpcclient_, done);
        }
        std::cout << key_ << "callback time out\n";
}

void RpcClient::SingleThreadMode(const ::google::protobuf::MethodDescriptor* method,
                           ::google::protobuf::RpcController* controller,
                           const ITdrObject* request,
                           ITdrObject* response,
                           ::google::protobuf::Closure* done) {
    std::string opcode = method->full_name();
    RpcCliMethod* cli_method = NULL;
    CroMgr mgr = GetCroMgr();
    int croid = coroutine_running(mgr);
    if (NULL == done) { // done参数空表示同步模式
        ::google::protobuf::Closure* syn_done = NULL;
        ::google::protobuf::Closure* cro_done = NULL;
        bool need_copy = false;
        if (-1 == croid) {
            printf("new coroutine fail\n");
            abort();
        } else { // 走协程,回调时resume
            cro_done = ::google::protobuf::NewCallback(&coroutine_resume, mgr, croid);
            need_copy = true; // 可能是局部变量，在协程外使用要复制一份
        }
        cli_method = new RpcCliMethod(controller,
                (ITdrObject*)request,
                response, syn_done, cro_done, need_copy);
    } else { // done非空表示异步模式
        // 再包装一层，异步回调执行时要用协程包着
        // 这样在里面再调用同步rpc时才可以用上yield
        ::google::protobuf::Closure* cro_closure =
            ::google::protobuf::NewCallback(&RpcMgr::RunWithCoroutine, done);
        cli_method = new RpcCliMethod(controller,
                (ITdrObject*)request,
                response, cro_closure, NULL);
    }
    unsigned newid = GetNextId();
    std::stringstream ss;
    ss << newid;
    std::string cli_id = ss.str();
    callback_map.Insert(ss.str(), cli_method);
    TimeCleaner* tc = new TimeCleaner(this, ss.str());
    std::string content;
    request->SerializeToString(&content);
    ss.str("");

    ss << "POST / HTTP/1.1\r\n"
        << "op: " << opcode << "\r\n"
        << "cli_id: " << newid << "\r\n"
        << "Content-Length: " << content.length() << "\r\n"
        << "\r\n"
        << content;
    timer.schedule(tc, (uint32)time_out_);
    PutSendQueue(ss.str());
    if (-1 != croid && NULL == done) {
        CroMgr mgr = GetCroMgr();
        coroutine_yield(mgr); // 同步协程模式要放权
        RpcCliMethod* rcm = cro_callback_map.Pop(cli_id);
        if (rcm) {
            if (controller && rcm->controller_) {
                ((CliController*)controller)->CopyFrom((CliController*)rcm->controller_);
            }
            if (!response->unpackTLV(rcm->response_string.c_str(),
                                     rcm->response_string.size())) {
                if (controller) {
                    controller->SetFailed("parse response error");
                }
                printf("parse response error\n");
            }
            RpcSafeFree(rcm);
        }
    }
}

void RpcClient::CallMethod(RpcController* rpcController,
                           const char* serviceName,
                           const char* methodName,
                           const ITdrObject* request,
                           ITdrObject* response,
                           IClosure* done) {
    SingleThreadMode(method, controller, request, response, done);
}

ProcessType SendProcess(void *argument) {
    ParamItem &param = (  *((ParamItem*)argument) );
    RpcClient &cli = ( *((RpcClient*)param.cli) );
    XSocket &sock = ( *((XSocket*)param.sock) );
    while (!cli.isstop) {
        //if (!sock.can_send(cli.time_out_)) {
        //    continue;
        //}
        std::string data = cli.GetSendQueue();
        if (data.empty())
            continue;
        while (true) {
            int ret = sock.send_n(data.c_str(), data.length(), cli.time_out_);
            if (ret > 0) {
                break;
            } else if (ret < 0 && !cli.isstop){
                ret = sock.reconnect(XSockAddr(cli.host_, cli.port_));
                if (ret < 0) {
                    printf("stop for remote connect fail\n");
                    cli.isstop = true;
                    cli._is_connected = false;
                    break;
                }
                param.consem.post();
            }
        }
    }
    return NULL;
}

void ProcessReturnData(std::string data, RpcClient* pcli) {
    RpcClient& cli = *pcli;
    CHttpParser ps;
    int ret = ps.parse_head(data.c_str(), data.length());
    if ( ret <= 0 ) {
        std::cout << data << " len: " << data.length() << " parse head error\n";
        return;
    }
    string cli_id = ps.get_head_field("cid");
    int content_len = ps.getContentLen();
    int headlen = data.length() - content_len;
    const char* content = data.c_str() + headlen;
    if (cli_id.empty() && cli._ext_processer) {
        std::string mes_name = ps.get_head_field("tn");
        std::string content_str;
        content_str.assign(content, content_len);
        IClosure* done = NewClosure(cli._ext_processer,
                mes_name, content_str, cli._ext_param);
        PushCallBack(cli, done);
        return;
    }
    RpcCliMethod* rcm = cli.callback_map.Pop(cli_id);
    if (NULL == rcm) {
        std::cout << " cli: " << cli_id << "null callback error\n";
        return;
    }
    IClosure* cro_done = rcm->cro_done_;
    if (cro_done) {
        rcm->response_string.assign(content, content_len);
        cli.cro_callback_map.Insert(cli_id, rcm);
        cro_done->Run(); // 协程resume,rcm在原处释放
        return;
    }
    ITdrObject* response = rcm->response_;
    if (0 != response->unpackTLV(content, content_len)) {
        if (rcm->controller_) {
            rcm->controller_->SetFailed("parse response error");
        }
        printf("parse response error\n");
    }
    IClosure* done = rcm->done_;
    PushCallBack(cli, done);
    delete rcm;
}

ProcessType ReadProcess(void *argument) {
    ParamItem &param = (  *((ParamItem*)argument) );
    RpcClient &cli = ( *((RpcClient*)param.cli) );
    XSocket &sock = ( *((XSocket*)param.sock) );
    int buf_size = 1024*100;
    char *buf = (char*)malloc(buf_size);
    char *last_left = buf;
    int left_len = 0;
    char* http_head = NULL;
    while (!cli.isstop) {
        int one_len = sock.recv_one_http(buf,buf_size,last_left,left_len,http_head,cli.time_out_);
        if (one_len > 0) {
            std::string data;
            data.assign(http_head, one_len);
            IClosure* done = NewClosure(ProcessReturnData, data, &cli);
            PushCallBack(cli, done);
        }
        else if (one_len < 0 && !cli.isstop){
            sock.mutex_close();
            if (cli._close_handler) {
                IClosure* done = NewClosure(cli._close_handler,cli._close_handler_param);
                PushCallBack(cli, done);
            }
            param.consem.wait();
        }
    }
    free(buf);
    return NULL;
}


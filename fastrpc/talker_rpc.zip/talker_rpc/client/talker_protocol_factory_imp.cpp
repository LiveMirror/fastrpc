#include "talker_protocol_factory.h"
#include "common_cpp/TdrObject.h"

namespace talker_test {

typedef apollo_test::ITdrObject* (*ObjectCreator)(void*, size_t);

class YourProtocolFactory : public ITalkerProtocolFactory {
    public:
        int GetTypeId() {
            return type_id_;
        }

        const char* GetTypeName() {
            return type_name_;
        }

        apollo_test::ITdrObject* Create() {
            return instance_creator_(NULL, 0);
        }

        apollo_test::ITdrObject* Singleton() {
            if (NULL == tdr_obj_) {
                tdr_obj_ = instance_creator_(NULL, 0);
            }

            return tdr_obj_;
        }

    public:
        static YourProtocolFactory* CreateFactoryInstance(int id, const char* name,
                                                          ObjectCreator creator) {
            return new YourProtocolFactory(id, name, creator);
        }

    private:
        YourProtocolFactory(int type_id, const char* type_name, ObjectCreator creator) :
            type_id_(type_id), type_name_(type_name), instance_creator_(creator), tdr_obj_(NULL) {}
        ~YourProtocolFactory(){}

    private:
        int type_id_;
        const char* type_name_;
        ObjectCreator instance_creator_;
        apollo_test::ITdrObject* tdr_obj_;
};

}

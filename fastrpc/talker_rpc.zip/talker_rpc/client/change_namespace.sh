#!/bin/bash
namespace="echo"
sed "s/mytalker/$namespace/" talker_app.cpp.template > talker_client_app.cpp

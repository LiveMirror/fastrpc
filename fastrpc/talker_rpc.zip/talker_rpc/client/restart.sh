./test_talker_client --id=1.1.5.1 --server_uri=tcp://127.0.0.1:8992 --pid-file=client.pid --appid=test -D restart

#ifndef __TLOG_H__
#define __TLOG_H__

#include "TLogDefine.h"

#ifdef __cplusplus
extern "C"
{
#endif
    void TLog (T_LOG_PRIORITY pri, const char *fmt,...);

#define LogInfo(fmt,...) TLog(TLOG_Pri_Info,fmt,##__VA_ARGS__)
#define LogDebug(fmt,...) TLog(TLOG_Pri_Debug,fmt,##__VA_ARGS__)
#define LogWarning(fmt,...) TLog(TLOG_Pri_Warning,fmt,##__VA_ARGS__)
#define LogError(fmt,...) TLog(TLOG_Pri_Error,fmt,##__VA_ARGS__)
#define LogEvent(fmt,...) TLog(TLOG_Pri_Event,fmt,##__VA_ARGS__)

    const char* GetLogLevelString(T_LOG_PRIORITY pri);
    void SetLogLevel(T_LOG_PRIORITY pri);

    typedef void (*TLogCallback)(T_LOG_PRIORITY pri, const char* msg);
    void SetTLogCallback(TLogCallback callback);

    char* GetErrMsg();

#ifdef __cplusplus
}
#endif

#endif

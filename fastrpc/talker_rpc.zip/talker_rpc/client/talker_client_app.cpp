#include "talker_client_app.h"
#include "talker_cpp/apollo_talker_metalib.h"
#include "version.h"
#include "tloghelp/tlogload.h"
// your game protocol factory encapsulation src
#include "talker_protocol_factory_imp.cpp"
#include "demo_cpp/echo_metalib.h"

namespace talker_test {

#define CONSOLE_CMD_SENDREQ "sendreq"
#define CONSOLE_CMD_SENDREP "sendrep"
#define CONSOLE_CMD_SENDNOTICE  "sendnotice"
#define CONSOLE_CMD_STATUS "status"

typedef struct {
    const char* cmd_name;
    int cmd_id;
} CmdDict;

CmdDict g_cmd_dict[] = {{CONSOLE_CMD_SENDREQ, DATA_TYPE_REQUEST},
                      {CONSOLE_CMD_SENDREP, DATA_TYPE_RESPONSE},
                      {CONSOLE_CMD_SENDNOTICE, DATA_TYPE_NOTICE}};

// define global static member variable
TAPPCTX TalkerClientApp::tapp_ctx_ = {};
uint32_t TalkerClientApp::async_seed_ = 0;
bool TalkerClientApp::server_ready_ = false;

static inline const char* GetMessageModel(int model) {
    switch(model)
    {
        case DATA_TYPE_NOTICE:
            return "NOTICE";
        case DATA_TYPE_REQUEST:
            return "REQUEST";
        case DATA_TYPE_RESPONSE:
            return "RESPONSE";
        default:
            return NULL;
    }
}

TalkerClientApp::TalkerClientApp() : tlogcat_inst_(NULL)
{
    msg_text_[0] = '\0';
}

TalkerClientApp::~TalkerClientApp()
{}

int TalkerClientApp::Run(int argc, char** argv)
{
    memset(&tapp_ctx_, 0, sizeof(tapp_ctx_));

    tapp_ctx_.argc = argc;
    tapp_ctx_.argv = argv;

    tapp_ctx_.pfnInit = tapp_init_cb_func;
    tapp_ctx_.pfnProc = tapp_proc_cb_func;
    tapp_ctx_.pfnTick = tapp_tick_cb_func;
    tapp_ctx_.pfnFini = tapp_fini_cb_func;
    tapp_ctx_.pfnArgv = tapp_user_cmdline_cb_func;

    tapp_ctx_.iLib = (intptr_t)0;
    tapp_ctx_.uiVersion = TAPP_MAKE_VERSION(MAJOR, MINOR, REV, BUILD);
    tapp_ctx_.stConfData.pszMetaName = NULL;
    tapp_ctx_.stRunDataCumu.pszMetaName = NULL;
    tapp_ctx_.stRunDataStatus.pszMetaName = NULL;
    tapp_ctx_.iNoLoadConf = 1;
    tapp_ctx_.iUseBus = 0;

    tapp_ctx_.pfnGetCtrlUsage = tapp_on_console_help_cb_func;
    tapp_ctx_.pfnProcCmdLine = tapp_on_ctrl_cb_func;

    tapp_set_brief_desc("talker test client");

    int ret = tapp_def_init(&tapp_ctx_, this);
    if (ret != 0)
    {
        fprintf(stderr, "tapp_def_init() failed:ret=%d\n", ret);
        return -1;
    }

    ret = tapp_def_mainloop(&tapp_ctx_, this);
    if (ret != 0)
    {
        fprintf(stderr, "tapp_def_mainloop() failed:ret=%d\n", ret);
    }

    tapp_def_fini(&tapp_ctx_, this);

    return 0;
}

int TalkerClientApp::Init()
{
    int ret = tapp_get_category(TLOG_DEF_CATEGORY_TEXTROOT, &tlogcat_inst_);
    if (ret != 0)
    {
        fprintf(stderr, "tapp_get_category:%s failed", TLOG_DEF_CATEGORY_TEXTROOT);
        return -1;
    }

    ret = conn_handler_.Init(this, tlogcat_inst_);
    if (ret != 0)
    {
        fprintf(stderr, "tgcpapi handler init failed");
        tlog_error(tlogcat_inst_, 0, 0, "tgcpapi handler init failed");
        return -1;
    }

    // register all prototypes
    for (int i=0; i<echo::MetaLib::TSTR2SN_SIZE; ++i)
    {
        YourProtocolFactory* factory = YourProtocolFactory::CreateFactoryInstance(
                                        -1, echo::MetaLib::typeStr2StaticNew[i].cmd,
                                        echo::MetaLib::typeStr2StaticNew[i].constructor);
        if (NULL == factory)
        {
            tlog_error(tlogcat_inst_, 0, 0, "create protocol factory failed");
            return -1;
        }

        ret = RegisterReflection(factory);
        if (ret != 0)
        {
            tlog_error(tlogcat_inst_, 0, 0, "register protocol reflection failed");
            return -1;
        }
    }

    return 0;
}

int TalkerClientApp::Fini()
{
    CancelAllReflections();
    conn_handler_.CleanUp();
    return 0;
}

int TalkerClientApp::Proc()
{
    // 忙闲控制
    int ret = conn_handler_.Update();
    if (ret < 0)
    {
        tlog_error(tlogcat_inst_, 0, 0, "tgcpapi handler update failed");
        return -1;
    }
    else if (ret > 0)
    {
        return 0;
    }
    else
    {
        tlog_trace(tlogcat_inst_, 0, 0, "idle");
        return -1;
    }
}

int TalkerClientApp::Tick()
{
    return 0;
}

int TalkerClientApp::RegisterUserCmd()
{
    int ret = 0;
    ret = tapp_register_option("server_uri", 's', 1,
                               "\n\t-s, --server_uri=[server uri]: specify server uri.",
                               tapp_str_opt_proc, &conn_handler_.option_.server_uri);
    if (ret < 0)
    {
        return -1;
    }

    ret = tapp_register_option("appid", 'a', 1,
                               "\n\t-a, --appid=[application id]: specify app id.",
                               tapp_str_opt_proc, &conn_handler_.option_.appid);
    if (ret < 0)
    {
        return -1;
    }

    ret = tapp_register_option("openid", 'o', 1,
                               "\n\t-o, --openid=[openid]: specify user openid.",
                               tapp_str_opt_proc, &conn_handler_.option_.openid);
    if (ret < 0)
    {
        return -1;
    }

    ret = tapp_register_option("atk", 't', 1,
                               "\n\t-t, --atk=[access token]: specify user access token.",
                               tapp_str_opt_proc, &conn_handler_.option_.atk);
    if (ret < 0)
    {
        return -1;
    }

    ret = tapp_register_option("auth_type", 0, 1,
                               "\n\t--auth_type=[auth type]: specify auth type[0:no auth 1:wx_code 2: wx_rtk 3: qq_atk].",
                               tapp_int_opt_proc, &conn_handler_.option_.auth_type);
    if (ret < 0)
    {
        return -1;
    }

    ret = tapp_register_option("acc_type", 0, 1,
                               "\n\t--acc_type=[account type]: specify account type[0:none 1:qq_uin 2: qq_openid 3: wx_openid].",
                               tapp_int_opt_proc, &conn_handler_.option_.account_type);
    if (ret < 0)
    {
        return -1;
    }

    ret = tapp_register_option("max_msg_size", 'm', 1,
                               "\n\t-m, --max_msg_size=[max msg size]: specify max game msg size.\n\n",
                               tapp_int_opt_proc, &conn_handler_.option_.max_msg_size);
    if (ret < 0)
    {
        return -1;
    }

    return 0;
}

const char* TalkerClientApp::GetConsoleHelp()
{
    const char* help =
        "Usage - [COMMAND] [MESSAGE NAME] [XML_FILE] [ASYNC_ID]\n"
        "    COMMAND: \n"
        "      - "CONSOLE_CMD_SENDREQ":    send request\n"
        "      - "CONSOLE_CMD_SENDREP":    send reply\n"
        "      - "CONSOLE_CMD_SENDNOTICE": send notice\n"
        //"      - "CONSOLE_CMD_STATUS":     check connection status, no argumets\n"
        "    ARGUMENTS: \n"
        "      - [MESSAGE NAME]: namespace.struct_name \n"
        "      - [XML_FILE]: message in XML formatted, which is stored in file\n"
        "      - [ASYNC_ID]: message async id";

    return help;
}

int TalkerClientApp::OnCtrl(unsigned short argc, const char** argv)
{
    if (0 == argc)
    {
        tlog_error(tlogcat_inst_, 0, 0, "no argc, assert failed");
        return -1;
    }

    // 如果是status，直接返回
    if (0 == strncmp(argv[0], CONSOLE_CMD_STATUS, strlen(CONSOLE_CMD_STATUS)))
    {
        if (server_ready_)
        {
            tappctrl_send_string("###CONNECTION HAS BEEN READY###");
        }
        else
        {
            tappctrl_send_string("###CONNECTION HAS NOT BEEN READY###");
        }

        return 0;
    }

    if (argc < 4)
    {
        tlog_error(tlogcat_inst_, 0, 0,
                   "has received command:%s, need at lease 3 arguments",
                   *argv);
        tappctrl_send_string("error: need at lease 3 arguments\n");
        return -1;
    }

    size_t i = 0;
    for (; i < sizeof(g_cmd_dict)/sizeof(CmdDict); ++i)
    {
        if (0 == strncmp(argv[0], g_cmd_dict[i].cmd_name, strlen(g_cmd_dict[i].cmd_name)))
        {
            break;
        }
    }

    if (i >= sizeof(g_cmd_dict)/sizeof(CmdDict))
    {
        tlog_error(tlogcat_inst_, 0, 0, "cmd:%s NOT supported", argv[0]);
        tapp_ctrl_printf("error: cmd:%s\n NOT supported\n", argv[0]);
        return -1;
    }

    // get prototype by name
    ITalkerProtocolFactory* factory = GetProtoTypeByName(argv[1]);
    if (NULL == factory)
    {
        tlog_error(tlogcat_inst_, 0, 0, "NULL factory found by name:[%s]", argv[1]);
        tapp_ctrl_printf("error: message name:%s unknown\n", argv[1]);
        return -1;
    }

    apollo_test::ITdrObject* msg = factory->Singleton();
    if (NULL == msg)
    {
        tlog_error(tlogcat_inst_, 0, 0, "factory get singleton failed");
        tappctrl_send_string("error: system inner error\n");
        return -1;
    }

    if (SendMsg(msg, argv[2], g_cmd_dict[i].cmd_id, atoi(argv[3])) != 0)
    {
        tlog_error(tlogcat_inst_, 0, 0, "SendMsg to server side failed");
        tappctrl_send_string("sendreq to server failed\n");
        return -1;
    }

    tapp_ctrl_printf("###ASYNC SEND MESSAGE SUCCEED. type:%s, asyc_id:%s###\n%s",
                     GetMessageModel(g_cmd_dict[i].cmd_id), argv[3], msg_text_);
    return 0;
}

int TalkerClientApp::SendMsg(apollo_test::ITdrObject* tdr_msg,
                             const char* conf_file_name,
                             int msg_model, uint32_t async_id)
{
    if (NULL == tdr_msg)
    {
        tlog_error(tlogcat_inst_, 0, 0, "assert failed");
        return -1;
    }

    TdrError::ErrorType tdr_ret = TdrError::TDR_NO_ERROR;

    // 1 TALKER首部戳
    // 1.1 construct TALKER head stamp
    TalkerHead talker_head_stamp;
    talker_head_stamp.dwAsync = async_id;
    talker_head_stamp.bFlag = DATA_FMT_MSG | DATA_FLOW_UP | DATA_TYPE_REQUEST;
    talker_head_stamp.bCmdFmt = CMD_FMT_STR;
    talker_head_stamp.bDomain = 1;
    if (strnlen(tdr_msg->typeName(), sizeof(talker_head_stamp.stCommand.szStrCmd))
        >= sizeof(talker_head_stamp.stCommand.szStrCmd))
    {
        tlog_error(tlogcat_inst_, 0, 0, "msg name len >= %u",
                   (unsigned)sizeof(talker_head_stamp.stCommand.szStrCmd));
        return -1;
    }
    strcpy(talker_head_stamp.stCommand.szStrCmd, tdr_msg->typeName());
    if (tlog_category_is_priority_enabled(tlogcat_inst_, TLOG_PRIORITY_DEBUG) &&
        tlog_category_can_write(tlogcat_inst_, TLOG_PRIORITY_DEBUG, 0, 0))
    {
        static char talker_text[1024];
        talker_head_stamp.visualize(talker_text, sizeof(talker_text));
        tlog_debug(tlogcat_inst_, 0, 0, "talker head to send:\n%s", talker_text);
    }

    static char msg_buff[10 * 1024 * 1024];
    size_t used = 0;
    // 1.2 pack TALKER head stamp
    tdr_ret = talker_head_stamp.packTLV(msg_buff, sizeof(msg_buff), &used, true);
    if (tdr_ret != TdrError::TDR_NO_ERROR)
    {
        tlog_error(tlogcat_inst_, 0, 0, "packTLV failed return %d, for %s",
                   tdr_ret, TdrError::getErrorString(tdr_ret));
        return -1;
    }

    // 2. 业务message
    // 2.1 input XML from file
    tdr_ret = tdr_msg->fromXmlFile(conf_file_name);
    if (tdr_ret != TdrError::TDR_NO_ERROR)
    {
        tlog_error(tlogcat_inst_, 0, 0, "fromXmlFile failed return %d, for %s",
                   tdr_ret, TdrError::getErrorString(tdr_ret));
        return -1;
    }

    if (tlog_category_is_priority_enabled(tlogcat_inst_, TLOG_PRIORITY_DEBUG) &&
        tlog_category_can_write(tlogcat_inst_, TLOG_PRIORITY_DEBUG, 0, 0))
    {
        tdr_msg->visualize(msg_text_, sizeof(msg_text_));
        tlog_debug(tlogcat_inst_, 0, 0, "msg to send:\n%s", msg_text_);
    }
    // 2.2 pack message
    size_t msg_used = 0;
    tdr_ret = tdr_msg->packTLV(msg_buff + used, sizeof(msg_buff) - used, &msg_used, true);
    if (tdr_ret != TdrError::TDR_NO_ERROR)
    {
        tlog_error(tlogcat_inst_, 0, 0, "packTLV failed return %d, for %s",
                   tdr_ret, TdrError::getErrorString(tdr_ret));
        return -1;
    }

    return conn_handler_.PushMessage(msg_buff, used + msg_used);
}

int TalkerClientApp::OnIncoming(const char* msg, size_t msg_size)
{
    if (NULL == msg || 0 == msg_size)
    {
        tlog_error(tlogcat_inst_, 0, 0, "msg<%p>==NULL OR msg_size<%u>==0",
                   msg, (unsigned)msg_size);
        return -1;
    }

    tlog_info(tlogcat_inst_, 0, 0, "recv msg size:%u", (unsigned)msg_size);

    TalkerHead talker_stamp;
    size_t used = 0;
    TdrError::ErrorType tdr_ret = talker_stamp.unpackTLV(msg, msg_size, &used);
    if (tdr_ret != TdrError::TDR_NO_ERROR)
    {
        tlog_error(tlogcat_inst_, 0, 0, "unpackTLV msg failed, return %d, for %s",
                   tdr_ret, TdrError::getErrorString(tdr_ret));
        return -1;
    }

    static char visu_buff[20480];
    if (tlog_category_is_priority_enabled(tlogcat_inst_, TLOG_PRIORITY_DEBUG) &&
        tlog_category_can_write(tlogcat_inst_, TLOG_PRIORITY_DEBUG, 0, 0))
    {
        talker_stamp.visualize(visu_buff, sizeof(visu_buff));
        tlog_debug(tlogcat_inst_, 0, 0, "recved talker stamp:\n%s", visu_buff);
    }

    if (DATA_FLOW_DOWN != (talker_stamp.bFlag & DATA_FLOW_MASK))
    {
        tlog_warn(tlogcat_inst_, 0, 0, "flow NOT downward, unexpected, ignore");
        return 0;
    }

    if (DOMAIN_APP != talker_stamp.bDomain)
    {
        tlog_warn(tlogcat_inst_, 0, 0, "domain NOT APP, unexpected, ignore");
        return 0;
    }

    if (DATA_FMT_BIN == (DATA_FMT_MASK & talker_stamp.bFlag))
    {
        tlog_warn(tlogcat_inst_, 0, 0, "data is bin format, transparet to local, ignore");
        return 0;
    }
    else if (DATA_FMT_MSG == (DATA_FMT_MASK & talker_stamp.bFlag))
    {
        if (CMD_FMT_STR != talker_stamp.bCmdFmt)
        {
            // drop
            tlog_warn(tlogcat_inst_, 0, 0, "cmd format is NOT string, ignore");
            return 0;
        }
        else if (CMD_FMT_NIL == talker_stamp.bCmdFmt)
        {
            tlog_error(tlogcat_inst_, 0, 0, "cmd format == CMD_NIL");
            return -1;
        }

        HandleTalkerMsg(talker_stamp, msg + used, msg_size - used);
    }

    return 0;
}

int TalkerClientApp::OnOutgoing()
{
    if (!server_ready_)
    {
        tlog_info(tlogcat_inst_, 0, 0, "server has been ready");
        server_ready_ = true;
    }

    return 0;
}

int TalkerClientApp::OnServerFull()
{
    tapp_exit_mainloop();
    tlog_info(tlogcat_inst_, 0, 0, "peer is full, tapp exit mainloop");
    tapp_ctrl_printf("###PEER SERVER IS FULL, SO TERMINATE###");

    return 0;
}

int TalkerClientApp::OnServerClose(int reason)
{
    tapp_exit_mainloop();
    tlog_info(tlogcat_inst_, 0, 0,
              "peer close for reason code:%d, tapp exit mainloop", reason);
    tapp_ctrl_printf("###PEER CLOSE, SO TERMINATE. reason_code:%d###", reason);

    return 0;
}

int TalkerClientApp::HandleTalkerMsg(const TalkerHead& talker_stamp,
                                     const char* app_data, size_t app_size)
{
    if (NULL == app_data || 0 == app_size)
    {
        tlog_error(tlogcat_inst_, 0, 0, "app_data<%p>==NULL OR app_size<%u>==0",
                   app_data, (unsigned)app_size);
        return -1;
    }

    switch (talker_stamp.bFlag & DATA_TYPE_MASK)
    {
        // 目前两种包的处理方式一致，可视化形式发给console
        case DATA_TYPE_NOTICE:
        case DATA_TYPE_REQUEST:
        case DATA_TYPE_RESPONSE:
            {
                ITalkerProtocolFactory* factory = GetProtoTypeByName(talker_stamp.stCommand.szStrCmd);
                if (NULL == factory)
                {
                    tlog_error(tlogcat_inst_, 0, 0, "get prototype by name:[%s] failed",
                               talker_stamp.stCommand.szStrCmd);
                    return -1;
                }
                apollo_test::ITdrObject* obj = factory->Singleton();
                if (NULL == obj)
                {
                    tlog_error(tlogcat_inst_, 0, 0, "get prototype by name:[%s] failed",
                               talker_stamp.stCommand.szStrCmd);
                    return -1;
                }

                TdrError::ErrorType tdr_ret = TdrError::TDR_NO_ERROR;
                size_t used = 0;
                tdr_ret = obj->unpackTLV(app_data, app_size, &used);
                if (tdr_ret != TdrError::TDR_NO_ERROR)
                {
                    tlog_error(tlogcat_inst_, 0, 0, "app data unpackTLV failed return %d, for %s",
                               tdr_ret, TdrError::getErrorString(tdr_ret));
                    return -1;
                }

                tdr_ret = obj->visualize(msg_text_, sizeof(msg_text_), &used);
                if (tdr_ret != TdrError::TDR_NO_ERROR)
                {
                    tlog_error(tlogcat_inst_, 0, 0, "visualize failed return %d, for %s",
                               tdr_ret, TdrError::getErrorString(tdr_ret));
                    return -1;
                }
                if (tlog_category_is_priority_enabled(tlogcat_inst_, TLOG_PRIORITY_DEBUG) &&
                    tlog_category_can_write(tlogcat_inst_, TLOG_PRIORITY_DEBUG, 0, 0))
                {
                    tlog_debug(tlogcat_inst_, 0, 0, "recved msg:\n%s", msg_text_);
                }
                tlog_notice(tlogcat_inst_, 0, 0, "client recv:%s\n", msg_text_);

                tapp_ctrl_printf("###RECV MESSAGE FROM SERVER. type:%s, async_id:%d###\n%s",
                                 GetMessageModel(talker_stamp.bFlag & DATA_TYPE_MASK),
                                 talker_stamp.dwAsync, msg_text_);
                break;
            }
        default:
            {
                tlog_error(tlogcat_inst_, 0, 0, "unknown data type:%d",
                           talker_stamp.bFlag & DATA_TYPE_MASK);
                break;
            }
    }

    return 0;
}

int TalkerClientApp::RegisterReflection(ITalkerProtocolFactory* factory)
{
    if (NULL == factory)
    {
        tlog_error(tlogcat_inst_, 0, 0, "reflection factory instance is invalid");
        return -1;
    }

    const char* type_name = factory->GetTypeName();
    if (NULL == type_name)
    {
        tlog_error(tlogcat_inst_, 0, 0, "null type_name");
        return -1;
    }

    const ReflectionMap::iterator iter = reflection_map_.find(std::string(type_name));
    if (iter != reflection_map_.end())
    {
        tlog_debug(tlogcat_inst_, 0, 0, "has register type:%s", type_name);
        return 0;
    }

    tlog_debug(tlogcat_inst_, 0, 0, "register reflection pair:[name:%s] -> [ptr:%p]",
               type_name, factory);
    reflection_map_.insert(std::pair<std::string, ITalkerProtocolFactory*>
                           (std::string(type_name), factory));
    return 0;
}

void TalkerClientApp::CancelAllReflections()
{
    ReflectionMap::iterator it = reflection_map_.begin();
    for (; it != reflection_map_.end(); ++it)
    {
        ITalkerProtocolFactory* factory = it->second;
        if (NULL != factory)
        {
            delete factory;
            it->second = NULL;
        }
    }

    reflection_map_.clear();
}

ITalkerProtocolFactory* TalkerClientApp::GetProtoTypeByName(const char* name)
{
    if (NULL == name)
    {
        tlog_error(tlogcat_inst_, 0, 0, "null message name");
        return NULL;
    }

    const ReflectionMap::iterator it = reflection_map_.find(std::string(name));
    if (it == reflection_map_.end())
    {
        tlog_error(tlogcat_inst_, 0, 0, "could NOT find prototype by name:[%s]", name);
        return NULL;
    }

    return it->second;
}

}

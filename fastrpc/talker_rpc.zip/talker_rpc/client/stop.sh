./test_talker_client --id=1.1.5.1 --pid-file=client.pid  stop

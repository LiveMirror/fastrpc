#include "talker_client_app.h"

int main(int argc, char** argv)
{
    talker_test::TalkerClientApp the_app;
    return the_app.Run(argc, argv);
}

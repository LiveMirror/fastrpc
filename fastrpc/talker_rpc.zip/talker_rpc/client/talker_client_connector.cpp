#include "talker_client_connector.h"
#include <string.h>

namespace talker_test {

ConnectorHandler::ConnectorHandler() : event_handler_(NULL), tlogcat_(NULL),
                                        hconn_(NULL)
{
    memset(&option_, 0, sizeof(option_));
    option_.appid = "";
    option_.atk = "";
    option_.max_msg_size = 10240;
    option_.openid = "";
    option_.server_uri = "tcp://127.0.0.1:9090";
    option_.auth_type = TGCP_AUTH_NONE;
    option_.account_type = TGCP_ACCOUNT_TYPE_NONE;
}

ConnectorHandler::~ConnectorHandler()
{}

int ConnectorHandler::Init(ITconnEventable* hevent, LPTLOGCATEGORYINST logcat)
{
    // 工具内部使用，强制要求传入tlog句柄
    if (NULL == hevent || NULL == logcat)
    {
        return -1;
    }

    event_handler_ = hevent;
    tlogcat_ = logcat;

    TGCPACCOUNT account;
    account.llUid = 0;
    account.uType = option_.account_type;
    strncpy(account.stAccountValue.szID, option_.openid,
            sizeof(account.stAccountValue.szID) - 1);
    int ret = tgcpapi_create_and_init(
                  &hconn_, 0,
                  option_.appid, strlen(option_.appid),
                  option_.max_msg_size,
                  &account, option_.atk, strlen(option_.atk)
                  );
    if (ret != TGCP_ERR_NONE)
    {
        tlog_error(tlogcat_, 0, 0, "tgcpapi_create_and_init failed return %d, for %s",
                   ret, tgcpapi_error_string(ret));
        return -1;
    }

    ret = tgcpapi_set_security_info(hconn_, TGCP_ENCRYPT_METHOD_NONE,
                                    TGCP_KEY_MAKING_NONE, NULL);
    if (ret != TGCP_ERR_NONE)
    {
        tlog_error(tlogcat_, 0, 0, "tgcpapi_set_security_info failed return %d, for %s",
                   ret, tgcpapi_error_string(ret));
        return -1;
    }

    if ((option_.auth_type > TGCP_AUTH_QQ_CT_LOGIN ||
        option_.auth_type < TGCP_AUTH_NONE)
        && option_.auth_type != TGCP_AUTH_VER_2)
    {
        ret = tgcpapi_set_authtype(hconn_, (eAuthType)option_.auth_type);
        if (ret != TGCP_ERR_NONE)
        {
            tlog_error(tlogcat_, 0, 0, "tgcpapi_set_authtype[authtype:%d] failed return %d, for %s",
                       option_.auth_type % TGCP_AUTH_QQ_CT_LOGIN, ret, tgcpapi_error_string(ret));
            return -1;
        }
    }

    ret = tgcpapi_start(hconn_, option_.server_uri);
    if (ret != TGCP_ERR_NONE)
    {
        tlog_error(tlogcat_, 0, 0, "tgcpapi_start failed return %d, for %s",
                   ret, tgcpapi_error_string(ret));
        return -1;
    }

    return 0;
}

// 由于本身作为测试工具使用，因此这里大部分事件不关注
int ConnectorHandler::Update()
{
    if (NULL == hconn_ || NULL == event_handler_)
    {
        tlog_error(tlogcat_, 0, 0, "assert failed");
        return -1;
    }

    GCPEVENT event;
    int ret = tgcpapi_update(hconn_, &event);
    if (ret != TGCP_ERR_NONE)
    {
        tlog_error(tlogcat_, 0, 0, "tgcpapi_update return %d, for %s",
                   ret, tgcpapi_error_string(ret));
        return -1;
    }

    // 由于测试工具目的是测试业务数据的正常交互。登录态的状态这里不加关注
    int busy = event.iEvtNum;
    if (event.iEvtNum > 0)
    {
        if (event.iEvents & TGCP_EVENT_SVR_IS_FULL)
        {
            tlog_notice(tlogcat_, 0, 0, "server is full");
            event_handler_->OnServerFull();
        }

        if (event.iEvents & TGCP_EVENT_SSTOPED)
        {
            tlog_notice(tlogcat_, 0, 0, "server close connection actively");
            event_handler_->OnServerClose(tgcpapi_get_sstop_reason(hconn_));
        }

        if (event.iEvents & TGCP_EVENT_WAITING)
        {
            tlog_notice(tlogcat_, 0, 0, "been waiting");
            event_handler_->OnWaiting();
        }

        if (event.iEvents & TGCP_EVENT_DATA_IN)
        {
            const char* msg = NULL;
            int msg_size = 0;
            int ret = tgcpapi_peek(hconn_, &msg, &msg_size, 0);
            if (ret != TGCP_ERR_NONE)
            {
                tlog_error(tlogcat_, 0, 0, "tgcpapi_peek failed return %d, for %s",
                           ret, tgcpapi_error_string(ret));
                return -1;
            }

            if (NULL == msg || 0 == msg_size)
            {
                tlog_error(tlogcat_, 0, 0, "msg is NULL, assert failed");
                return -1;
            }

            event_handler_->OnIncoming(msg, msg_size);
        }

        if (event.iEvents & TGCP_EVENT_DATA_OUT)
        {
            busy--;
            event_handler_->OnOutgoing();
        }

        if (event.iEvents & TGCP_EVENT_ATK)
        {
            event_handler_->OnAtkRefreshed();
        }
    }

    return busy;
}

void ConnectorHandler::CleanUp()
{
    if (NULL == hconn_)
    {
        tlog_error(tlogcat_, 0, 0, "assert failed");
        return;
    }

    tgcpapi_stop(hconn_);
    tgcpapi_fini(hconn_);
    tgcpapi_destroy(&hconn_);
}

int ConnectorHandler::PushMessage(const char* msg, size_t msg_size)
{
    if (NULL == hconn_)
    {
        tlog_error(tlogcat_, 0, 0, "assert failed");
        return -1;
    }

    int ret = tgcpapi_send(hconn_, msg, msg_size, 0);
    if (ret != TGCP_ERR_NONE)
    {
        tlog_error(tlogcat_, 0, 0, "tgcpapi_send failed return %d, for %s",
                   ret, tgcpapi_error_string(ret));
        return -1;
    }

    return 0;
}

}

#ifndef __VERSION_AUTO_H
#define __VERSION_AUTO_H
#define MAJOR 1
#define MINOR 0
#define REV 0
#define BUILD 20150213
#endif


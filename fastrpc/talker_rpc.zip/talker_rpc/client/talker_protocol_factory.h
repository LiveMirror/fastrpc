#ifndef TALKER_PROTOCOL_FACTORY_H_
#define TALKER_PROTOCOL_FACTORY_H_

#include "common_cpp/TdrObject.h"

namespace talker_test {

class ITalkerProtocolFactory {
    public:
        ITalkerProtocolFactory(){}
        virtual ~ITalkerProtocolFactory(){}

    public:
        virtual int GetTypeId() {return -1;}
        virtual const char* GetTypeName() {return NULL;}
        virtual apollo_test::ITdrObject* Create(){return NULL;}
        virtual apollo_test::ITdrObject* Singleton(){return NULL;}
};

}

#endif

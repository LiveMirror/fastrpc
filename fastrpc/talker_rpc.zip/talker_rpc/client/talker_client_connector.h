#ifndef TALKER_CLIENT_CONNECTOR_H_
#define TALKER_CLIENT_CONNECTOR_H_

#include "tgcpapi/tgcpapi_ex.h"
#include "tlog/tlog.h"

namespace talker_test {

class ITconnEventable {
    public:
        ITconnEventable(){}
        virtual ~ITconnEventable(){}

    public:
        virtual int OnServerFull() {return 0;}
        virtual int OnServerClose(int reason) {return 0;}
        virtual int OnWaiting() {return 0;}
        virtual int OnIncoming(const char* msg, size_t msg_size) {return 0;}
        virtual int OnOutgoing() {return 0;}
        virtual int OnAtkRefreshed() {return 0;}
};

typedef struct {
    const char* server_uri;
    const char* appid;
    const char* openid;
    const char* atk;
    int auth_type;
    int account_type;
    int max_msg_size;
} TalkerOption;

class TalkerClientApp;
class ConnectorHandler {
    public:
        ConnectorHandler();
        virtual ~ConnectorHandler();

    public:
        int Init(ITconnEventable* hevent, LPTLOGCATEGORYINST logcat);
        int Update();
        void CleanUp();

    public:
        int PushMessage(const char* msg, size_t msg_size);

    private:
        ITconnEventable* event_handler_;
        LPTLOGCATEGORYINST tlogcat_;

    private:
        HTGCPAPI hconn_;
        TalkerOption option_;

        friend class TalkerClientApp;
};

}

#endif

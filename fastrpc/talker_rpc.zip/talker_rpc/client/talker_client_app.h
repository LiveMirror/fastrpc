#ifndef TALKER_CLIENT_APP_H_
#define TALKER_CLIENT_APP_H_

#include "talker_client_connector.h"
#include "talker_cpp/apollo_talker.h"
#include "talker_protocol_factory.h"
#include "tapp/tapp.h"
#include <map>
#include <string>

namespace talker_test {

using namespace apollo_talker;
class TalkerClientApp : ITconnEventable {
    public:
        TalkerClientApp();
        virtual ~TalkerClientApp();

    public:
        int Run(int argc, char **argv);

    public:
        virtual int OnIncoming(const char* msg, size_t msg_size);
        virtual int OnOutgoing();
        virtual int OnServerFull();
        virtual int OnServerClose(int reason);

    private:
        int HandleTalkerMsg(const TalkerHead& talker_stamp,
                            const char* app_data, size_t app_size);
        int RegisterReflection(ITalkerProtocolFactory* factory);
        void CancelAllReflections();
        ITalkerProtocolFactory* GetProtoTypeByName(const char* name);
        int SendMsg(apollo_test::ITdrObject* tdr_msg, const char* conf_file_name,
                    int msg_model, uint32_t async_id);

    private:
        int Init();
        int Fini();
        int Proc();
        int Tick();

    private:
        int RegisterUserCmd();
        int OnCtrl(unsigned short argc, const char** argv);
        static const char* GetConsoleHelp();

    private:
        // C style callback
        static int tapp_init_cb_func(TAPPCTX* ctx, void* arg) {
            if (NULL == arg) {
                return -1;
            }

            return static_cast<TalkerClientApp*>(arg)->Init();
        }

        static int tapp_proc_cb_func(TAPPCTX* ctx, void* arg) {
            if (NULL == arg) {
                return -1;
            }

            return static_cast<TalkerClientApp*>(arg)->Proc();
        }

        static int tapp_tick_cb_func(TAPPCTX* ctx, void* arg) {
            if (NULL == arg) {
                return -1;
            }

            return static_cast<TalkerClientApp*>(arg)->Tick();
        }

        static int tapp_fini_cb_func(TAPPCTX* ctx, void* arg) {
            if (NULL == arg) {
                return -1;
            }

            return static_cast<TalkerClientApp*>(arg)->Fini();
        }

        static int tapp_user_cmdline_cb_func(TAPPCTX* ctx, void* arg) {
            if (NULL == arg) {
                return -1;
            }

            return static_cast<TalkerClientApp*>(arg)->RegisterUserCmd();
        }

        static const char* tapp_on_console_help_cb_func() {
            return GetConsoleHelp();
        }

        static int tapp_on_ctrl_cb_func(TAPPCTX* ctx, void* arg,
                                        unsigned short argc, const char** argv) {
            if (NULL == arg) {
                return -1;
            }

            return static_cast<TalkerClientApp*>(arg)->OnCtrl(argc, argv);
        }

    private:
        static TAPPCTX tapp_ctx_;
        static uint32_t async_seed_;
        static bool server_ready_;
        LPTLOGCATEGORYINST tlogcat_inst_;

    private:
        ConnectorHandler conn_handler_;
        char msg_text_[20480];

    private:
        typedef std::map<std::string, ITalkerProtocolFactory*> ReflectionMap;
        ReflectionMap reflection_map_;
};

}


#endif

#./tdr -P --with_from_xml --with_to_xml --with_base_class test_service_rpc.xml -O .
./tdr -P --with_from_xml --with_to_xml --with_base_class --no_comm_files echo_protocol.xml -O .
sed -i "s/tsf4g_tdr/apollo/g" `grep -rl tsf4g_tdr *.h`
sed -i "s/tsf4g_tdr/apollo/g" `grep -rl tsf4g_tdr *.cpp`

#include "talker_server.h"
#include "echo_protocol.h"
#include "coroutine.h"

class Test {
public:
    int Echo(ITConnTalker* talker,
             shared_ptr<ETConnConnection> conn,
             const shared_ptr<ETConnRecvedMsg> msg) {
        const echo::EchoRequest* echo_req =
            dynamic_cast<const echo::EchoRequest*>(msg->GetObj());

        conn->SetSessionID(-1);
        echo::EchoRequest rsp;
        std::string new_s = "haha server1 back res";
        std::string push_s = "haha server1 push notice";

        if (talker != NULL) {
            strcpy(rsp.szInfo, new_s.c_str());
            talker->SendResponseMsg(*conn, rsp, msg->GetAsync());
            strcpy(rsp.szInfo, push_s.c_str());
            talker->SendNoticeMsg(*conn, rsp);
        }
        return 0;
    }
};

class MyHttpHandler : public HttpHandler {
public:
    virtual void Init(CASyncSvr* svr) {}
    virtual void OnRec(HttpRequest* request,
                       ::google::protobuf::Closure *done) {
        CHttpParser* ps = request->ps;
        ps->parse_form_body();
        std::string kk = ps->get_param("kk");
        string str_cmd = ps->get_object();
        string get_uri = ps->get_uri();
        std::stringstream ss;
        ss << "kk:" << kk << "<br/>"
            << "cmd:" << str_cmd << "<br/>"
            << "uri:" << get_uri << "<br/>";

        std::string content_type = "text/html";
        std::string add_head = "Connection: keep-alive\r\n";
        CHttpResponseMaker::make_string(ss.str(),
                                        request->response,
                                        content_type,
                                        add_head);

        if (done) {
            done->Run();
        }
    }
    virtual void Finish(CASyncSvr* svr) {}
};

int main(int argc, char** argv)
{
    Test test;
    static TalkerServer myapp;
    RegiMsgHandler(myapp, echo::EchoRequest, &test, &Test::Echo);
    myapp.RegiTcpSvr("127.0.0.1", 8997);
    HttpHandler *http_handler = new MyHttpHandler();
    myapp.tcp_svr->RegiHttpHandler(http_handler);
    return tapp::AppLauncher::Run(&myapp, argc, argv);
}
